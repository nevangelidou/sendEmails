﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendEmails
{
    public class SendMailTest
    {
        public SendMailTest()
        {

        }

        public static void SendMailstest(string[] filePaths5)
        {
            {

                //προσθήκη νέου path που θα τραβάει τα αρχεία
                filePaths5 = Directory.GetFiles(@"L:\Prices\test\", "test*");



                DateTime today = DateTime.Today;

                string br = "";

                //δημιουργία email
                Console.WriteLine("\nΑποστολή mail...");

                DateTime today1 = today;
                EmailClass.SendMail(new string[] { "nevangelidou@masoutis.gr" }, new string[] { "spapadopoulos@masoutis.gr,amylonidis@masoutis.gr" },
                    "Barcode τιμολογίων (ΜΑΣΟΥΤΗΣ)" + today1.ToString("dd/MM/yyyy"), "", filePaths5);

                //EmailClass.SendMail(new string[] { "dgkanatsios@masoutis.gr" }, new string[] { "nevangelidou@masoutis.gr,aflokas@masoutis.gr" },
                //    "Barcode τιμολογίων (ΜΑΣΟΥΤΗΣ)" + today1.ToString("dd/MM/yyyy"), "Καλημέρα σας", filePaths2);



                Console.WriteLine("\nΤο mail στάλθηκε...");

                //System.Threading.Thread.Sleep(5000);

                //μεταφορά στο backup

                Console.WriteLine("\nΜεταφορά αρχείων στο Backup path...");
                foreach (var item in filePaths5)
                {
                    File.Move(item, Path.Combine("L:\\prices\\test\\Backup\\", Path.GetFileName(item)));
                    //Console.WriteLine(Path.Combine("C:\\Desktop\\", Path.GetFileName(item)));
                }



            }














        }
    }
}