﻿using System.Threading;
using System;
using System.Diagnostics;
using System.IO;
using System.Xml.Linq;

namespace SendEmails
{
    internal class Program
    {
        public static DateTime Today { get; }
        DateTime yesterday = DateTime.Today.AddDays(-1);
        DateTime today = DateTime.Today;
        static void Main(string[] args)
        {
            Console.WriteLine("Starting SendEmails App...");



            //προσθήκη νέου path που θα τραβάει τα αρχεία
            string[] filePaths = Directory.GetFiles(@"L:\Prices\WINBANK\", "Winbank_*"); //winbank
            string[] filePaths2 = Directory.GetFiles(@"L:\Prices\ANEMOS\", "Anemos_*"); //anemos
            string[] filePaths3 = Directory.GetFiles(@"L:\Prices\4ALL\", "4ALL_*");     //4all
            string[] filePaths4 = Directory.GetFiles(@"L:\Prices\EKO\", "EKO_*");    //eko
           
            string[] filePaths5 = Directory.GetFiles(@"L:\Prices\test\", "test*");    //test

            string[] filePaths6 = Directory.GetFiles(@"L:\BulkCustItems\EKO\Prices\", "*.csv");    //eko 2η αναφορά

            DateTime yesterday = DateTime.Today.AddDays(-1);
            DateTime today = DateTime.Today;

            //winbank
            //βγάζει μήνυμα ερρορ σε περίπτωση που δεν υπάρχουν στοιχεία για αποστολή
            if (filePaths.Length == 0)
            {
                Console.WriteLine("\nΔεν υπάρχουν αρχεία για αποστολή στην Πειραιώς...");
            }

            else
            {
                string br = "";
                SendMailWinbank.SendMailsWinbank(filePaths);


            }

            //anemos
            if (filePaths2.Length == 0)
            {
                Console.WriteLine("\nΔεν υπάρχουν αρχεία για αποστολή στον ΑΝΕΜΟ...");
            }
            else
            {
                string br = "";
                SendMailAnemos.SendMailsAnemos(filePaths2);
            }

            //4all

            if (filePaths3.Length == 0)
            {
                Console.WriteLine("\nΔεν υπάρχουν αρχεία για αποστολή στα 4all ...");
            }

            else
            {
                string br = "";
                SendMail4all.SendMails4all(filePaths3);


            }

            //eko
            if (filePaths4.Length == 0)
            {
                Console.WriteLine("\nΔεν υπάρχουν αρχεία για αποστολή στην EKO...");
            }

            else
            {
                string br = "";
                SendMailEKO.SendMailsEKO(filePaths4);



            }

            //eko 2η αναφορά
            if (filePaths6.Length == 0)
            {
                Console.WriteLine("\nΔεν υπάρχουν αρχεία για αποστολή στην EKO για την 2η αναφορά...");
            }

            else
            {
                string br = "";
                SendMailEKO2.SendMailsEKO2(filePaths6);



            }

            //test

            if (filePaths5.Length == 0)
            {
                Console.WriteLine("\nΔεν υπάρχουν αρχεία για αποστολή test..");
            }

            else
            {
                string br = "";
                SendMailTest.SendMailstest(filePaths5);


            }

            Console.WriteLine("\nClosing...");
            Thread.Sleep(5000);
           
        }
    }
}
