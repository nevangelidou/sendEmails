﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendEmails
{
    public class SendMailWinbank
    {
        public SendMailWinbank()
        {

        }
        public static void SendMailsWinbank(string[] filePaths)
        {
            {

                //προσθήκη νέου path που θα τραβάει τα αρχεία
                filePaths = Directory.GetFiles(@"L:\Prices\WINBANK\", "Winbank_*");



                DateTime yesterday = DateTime.Today.AddDays(-1);

                string bre = "";
                //δημιουργία email
                Console.WriteLine("\nΑποστολή mail...");

                DateTime yesterday1 = yesterday;
                EmailClass.SendMail(new string[] { "TzouliadakiE@piraeusbank.gr,KougoulouS@piraeusbank.gr,NikolaouF@piraeusbank.gr,yellowfinancial@piraeusbank.gr,RepanisI@piraeusbank.gr" },
                    new string[] { "nevangelidou@masoutis.gr,spapadopoulos@masoutis.gr,amylonidis@masoutis.gr"/*"nevangelidou@masoutis.gr,dgkanatsios@masoutis.gr"*/ },
                   "Δωροεπιταγές Μασούτης έως " + yesterday1.ToString("dd/MM/yyyy"), "", filePaths);

                //"TzouliadakiE@piraeusbank.gr,KougoulouS@piraeusbank.gr,NikolaouF@piraeusbank.gr,yellowfinancial@piraeusbank.gr" },
                //new string[] { "nevangelidou@masoutis.gr,spapadopoulos@masoutis.gr,dmeliopoulos@masoutis.gr" },


                Console.WriteLine("\nΤο mail στάλθηκε...");

                //System.Threading.Thread.Sleep(5000);

                //μεταφορά στο backup

                Console.WriteLine("\nΜεταφορά αρχείων στο Backup path...");
                foreach (var item in filePaths)
                {
                    File.Move(item, Path.Combine("L:\\prices\\WINBANK\\Backup\\", Path.GetFileName(item)));
                    //Console.WriteLine(Path.Combine("C:\\Desktop\\", Path.GetFileName(item)));
                }


            }




        }
    }
}