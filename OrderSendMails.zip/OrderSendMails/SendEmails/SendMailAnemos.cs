﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendEmails
{
    public class SendMailAnemos
    {
        public SendMailAnemos()
        {

        }

        public static void SendMailsAnemos(string[] filePaths2)
        {
            {

                //προσθήκη νέου path που θα τραβάει τα αρχεία
                filePaths2 = Directory.GetFiles(@"L:\Prices\ANEMOS\", "Anemos_*");



                DateTime today = DateTime.Today;

                string br = "";

                //δημιουργία email
                Console.WriteLine("\nΑποστολή mail...");

                DateTime today1 = today;
                EmailClass.SendMail(new string[] { "dora.georgiou@mascy.net" }, new string[] { "nevangelidou@masoutis.gr,spapadopoulos@masoutis.gr,amylonidis@masoutis.gr" },
                    "Barcode τιμολογίων (ΜΑΣΟΥΤΗΣ)" + today1.ToString("dd/MM/yyyy"), "", filePaths2);

                //EmailClass.SendMail(new string[] { "dgkanatsios@masoutis.gr" }, new string[] { "nevangelidou@masoutis.gr,aflokas@masoutis.gr" },
                //    "Barcode τιμολογίων (ΜΑΣΟΥΤΗΣ)" + today1.ToString("dd/MM/yyyy"), "Καλημέρα σας", filePaths2);



                Console.WriteLine("\nΤο mail στάλθηκε...");

                //System.Threading.Thread.Sleep(5000);

                //μεταφορά στο backup

                Console.WriteLine("\nΜεταφορά αρχείων στο Backup path...");
                foreach (var item in filePaths2)
                {
                    File.Move(item, Path.Combine("L:\\prices\\ANEMOS\\Backup\\", Path.GetFileName(item)));
                    //Console.WriteLine(Path.Combine("C:\\Desktop\\", Path.GetFileName(item)));
                }



            }














        }
    }
}