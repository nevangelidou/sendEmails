﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendEmails
{
    public class SendMail4all
    {
        public SendMail4all()
        {

        }

        public static void SendMails4all(string[] filePaths3)
        {
            {

                //προσθήκη νέου path που θα τραβάει τα αρχεία
                filePaths3 = Directory.GetFiles(@"L:\Prices\4ALL\", "4ALL_*");



                DateTime today = DateTime.Today;

                string br = "";

                //δημιουργία email
                Console.WriteLine("\nΑποστολή mail...");

                DateTime today1 = today;
                EmailClass.SendMail(new string[] { "a.troupkou@4allstores.gr,sdachtyloudi@4allstores.gr,apapadimitriou@4allstores.gr" }, new string[] { "nevangelidou@masoutis.gr,spapadopoulos@masoutis.gr,amylonidis@masoutis.gr" },
                    "Αρχείο ΜΑΣΟΥΤΗ στις " + today1.ToString("dd/MM/yyyy"), "", filePaths3);

                //EmailClass.SendMail(new string[] { "dgkanatsios@masoutis.gr" }, new string[] { "nevangelidou@masoutis.gr,aflokas@masoutis.gr" },
                //    "Barcode τιμολογίων (ΜΑΣΟΥΤΗΣ)" + today1.ToString("dd/MM/yyyy"), "Καλημέρα σας", filePaths2);



                Console.WriteLine("\nΤο mail στάλθηκε...");

                //System.Threading.Thread.Sleep(5000);

                //μεταφορά στο backup

                Console.WriteLine("\nΜεταφορά αρχείων στο Backup path...");
                foreach (var item in filePaths3)
                {
                    File.Move(item, Path.Combine("L:\\prices\\4ALL\\Backup\\", Path.GetFileName(item)));
                    //Console.WriteLine(Path.Combine("C:\\Desktop\\", Path.GetFileName(item)));
                }



            }














        }
    }
}