﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendEmails
{
    public class SendMailEKO2
    {
        public SendMailEKO2()
        {

        }

        public static void SendMailsEKO2(string[] filePaths6)
        {
            {

                //προσθήκη νέου path που θα τραβάει τα αρχεία
                filePaths6 = Directory.GetFiles(@"L:\BulkCustItems\EKO\Prices\", "*.csv");



                DateTime today = DateTime.Today;

                string br = "";

                //δημιουργία email
                Console.WriteLine("\nΑποστολή mail...");

                DateTime today1 = today;
                EmailClass.SendMail(new string[] { "proumpi@helpe.gr,gkiposis@eko.helleniq.gr,igaliouris@eko.helleniq.gr,okovatska@eko.helleniq.gr" }, new string[] { "nevangelidou@masoutis.gr,spapadopoulos@masoutis.gr,amylonidis@masoutis.gr,msimeonidis@masoutis.gr" },
                    "Αρχείο ΕΚΟ Πρατηρίων Conve North για " + today1.ToString("dd/MM/yyyy"), "", filePaths6);




                Console.WriteLine("\nΤο mail στάλθηκε...");

                //System.Threading.Thread.Sleep(5000);

                //μεταφορά στο backup

                Console.WriteLine("\nΜεταφορά αρχείων στο Backup path...");
                foreach (var item in filePaths6)
                {
                    File.Move(item, Path.Combine("L:\\BulkCustItems\\EKO\\Prices\\Bck\\", Path.GetFileName(item)));
               

               
                }



            }














        }
    }
}