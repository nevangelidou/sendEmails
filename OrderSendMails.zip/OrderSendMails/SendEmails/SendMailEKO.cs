﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendEmails
{
    public class SendMailEKO
    {
        public SendMailEKO()
        {

        }

        public static void SendMailsEKO(string[] filePaths4)
        {
            {

                //προσθήκη νέου path που θα τραβάει τα αρχεία
                filePaths4 = Directory.GetFiles(@"L:\Prices\EKO\", "EKO_*");



                DateTime today = DateTime.Today;

                string br = "";

                //δημιουργία email
                Console.WriteLine("\nΑποστολή mail...");

                DateTime today1 = today;
                EmailClass.SendMail(new string[] { "proumpi@helpe.gr,igaliouris@eko.helleniq.gr, okovatska@eko.helleniq.gr" }, new string[] { "nevangelidou@masoutis.gr,spapadopoulos@masoutis.gr,amylonidis@masoutis.gr" },
                    "Αρχείο ΕΚΟ στις " + today1.ToString("dd/MM/yyyy"), "", filePaths4);

                //EmailClass.SendMail(new string[] { "dgkanatsios@masoutis.gr" }, new string[] { "nevangelidou@masoutis.gr,aflokas@masoutis.gr" },
                //    "Barcode τιμολογίων (ΜΑΣΟΥΤΗΣ)" + today1.ToString("dd/MM/yyyy"), "Καλημέρα σας", filePaths2);



                Console.WriteLine("\nΤο mail στάλθηκε...");

                //System.Threading.Thread.Sleep(5000);

                //μεταφορά στο backup

                Console.WriteLine("\nΜεταφορά αρχείων στο Backup path...");
                foreach (var item in filePaths4)
                {
                    File.Move(item, Path.Combine("L:\\prices\\EKO\\Backup\\", Path.GetFileName(item)));
                    //Console.WriteLine(Path.Combine("C:\\Desktop\\", Path.GetFileName(item)));
                }



            }














        }
    }
}