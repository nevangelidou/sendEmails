﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace SendEmails
{
    public class EmailClass
    {
        public EmailClass()
        {

        }
        public static void SendMail(string[] to, string[] cc, string subject, string body, string[] attachments)
        {
            try
            {
                string from = "masreports@masoutis.gr";
                SmtpClient SmtpServer = new SmtpClient();
                using (MailMessage mail = new MailMessage())
                {
                    //MailMessage mail = new MailMessage();
                    StringBuilder mailbody = new StringBuilder();
                    SmtpServer.Port = 587;
                    SmtpServer.Host = "smtp.office365.com";
                    SmtpServer.Credentials = new NetworkCredential("smtp.office365.com\\masreports@masoutis.gr", "u3Ey^2628xXB");
                    SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
                    SmtpServer.EnableSsl = true;

                    string br = "";

                    mail.From = new MailAddress(from);
                    //mail.To.Add(to);
                    to.ToList().ForEach(x => mail.To.Add(x));
                    cc.ToList().ForEach(x => mail.CC.Add(x));
                    mail.Subject = subject;
                    //if (cc != "")
                    //    mail.CC.Add(cc);
                    mail.IsBodyHtml = true;

                    mailbody.Append(body);

                    mail.Body = mailbody.ToString();

                    foreach (string file in attachments)
                    {
                        Attachment attachment;
                        attachment = new Attachment(file);
                        mail.Attachments.Add(attachment);
                    }

                    SmtpServer.Send(mail);

                    mail.Attachments.Dispose();
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

    }
}
